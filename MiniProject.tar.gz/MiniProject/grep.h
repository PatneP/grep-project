
/*****************************************************************************
 * Copyright (C) Pranali R.P. pranalir.patne@gmail.com
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/
#include<stdio.h>

// Gets the next line from the text file, returns the pointer to that line
char* getLine(char* loc, FILE* fileStream);
// Returns whether the given string contains the specified search pattern
int checkStringMatch(char* toSearch, char* pattern);
// Returns a lowercase copy of the string
char* switchToLower(char* string);
// Prints the given line to stdout, with lineNum if nonzero
void printLine(int lineNum, char* fileName, char* text,char * pattern);
// Processes a file, printing any lines in that file that match the given search pattern
void processfile(char* filename, char* pattern );
// Checks for possible options and returns the number of enabled options
int checkoptions(char* argv[]);
// used to give color to the pattern

void setClr(char* text, char* pattern);
// Global variables hold option state
int optionn = 0;
int optioni = 0;
int optionc = 0;int count=0;
int optionv = 0;
int optionH = 0;
int optionh = 0;
int optionr = 0;
int optionf = 0;
int optiony = 0;
int optionw = 0;

