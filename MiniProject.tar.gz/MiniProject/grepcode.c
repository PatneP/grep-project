
/*****************************************************************************
 * Copyright (C) Pranali R.P. pranalir.patne@gmail.com
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
 *****************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>
#include "grep.h"
#define MAX  500
#define RED   "\x1B[31m"
#define GRN   "\x1B[32m"
#define YEL   "\x1B[33m"
#define BLU   "\x1B[34m"
#define MAG   "\x1B[35m"
#define CYN   "\x1B[36m"
#define WHT   "\x1B[37m"
#define RESET "\x1B[0m"


int main(int argc, char* argv[]){
	// Make sure the minimum number of arguments is present
	if(argc < 3){
		fputs("\nUsage :\n\t ./project <options> <Pattern> <file-name>\n",stderr);
		fputs("\tMust provide a search pattern and at least 1 file.\n", stderr);
			return 1;
	}

	// Number of enabled options, used check that the search pattern is in argv
	int numoptions = checkoptions(argv);
	// Holds the search pattern
	char* pattern = argv[numoptions+ 1];

	// If "-i" is used, change the pattern to lowercase
	if(optioni){
		pattern = switchToLower(pattern);
	}

	int i;
	i=numoptions + 2;
	while( i < argc){
		char* filename = argv[i];
		processfile(filename, pattern);
		 i++;
	}
	// the switchToLower function resulted in pattern being malloc'd
	if(optioni)
	{
		free(pattern);
	}
	return 0;
}

int checkoptions(char* argv[]){
	int numOptions = 0;
	
	if(checkStringMatch(argv[1], "-n") || checkStringMatch(argv[2], "-n"))
	{
		optionn = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-i") || checkStringMatch(argv[2], "-i"))
	{
		optioni = 1;
		numOptions++;
	} 
	if(checkStringMatch(argv[1], "-c") || checkStringMatch(argv[2], "-c"))
	{
		optionc = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-v") || checkStringMatch(argv[2], "-v"))
	{
		optionv = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-H") || checkStringMatch(argv[2], "-H"))
	{
		optionH = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-h") || checkStringMatch(argv[2], "-h"))
	{
		optionh = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-r") || checkStringMatch(argv[2], "-r"))
	{
		optionr = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-f") || checkStringMatch(argv[2], "-f"))
	{
		optionf = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-y") || checkStringMatch(argv[2], "-y"))
	{
		optiony = 1;
		numOptions++;
	}
	if(checkStringMatch(argv[1], "-w") || checkStringMatch(argv[2], "-w"))
	{
		optionw = 1;
		numOptions++;
	}
	
return numOptions;
}

void processfile(char* filename, char* pattern){
	int ch = 0, flag = 0;
	FILE* f = fopen(filename, "r");
	FILE* fp = fopen(filename, "r");
	int count=0;
	if(!f)
	{
	fprintf(stderr, "File %s unopenable.\n", filename);
	return;
	}
	if(!fp)
	{
	fprintf(stderr, "File %s unopenable.\n", filename);
	return;
	}

	// Will hold each line scanned in from the file
	char* line = (char*)malloc(MAX*sizeof(char)); 
	char* line1 = (char*)malloc(MAX*sizeof(char)); 
	int lineNum = 1;
	while(!feof(f) && !feof(fp)){
		line = getLine(line, f);
		line = getLine(line1, fp);
		// Only proceed if the line is non-null
		if(line && line1)
		{
			
			//  "-i" option is used compare the string after stripping case
			if(optioni)
			{
				char* lowerLine = switchToLower(line);
				if(checkStringMatch(lowerLine, pattern))
				{
					printLine(lineNum*optioni, filename, line, pattern);
				}
				free(lowerLine);
			}

			// "-c" option is used to print NUM lines of output context
			if (optionc)
			{				
				if(checkStringMatch(line, pattern))
				{
					count++;
				}
			}		

			// " -n " option is used to print line number with output lines
			if (optionn)
			{
				if(checkStringMatch(line, pattern))
				{
					printLine(lineNum*optionn, filename, line, pattern);
				}
			 }

			// " -v " option is used to select non-matching lines
			if (optionv)
			{
				if(checkStringMatch(line, pattern))
				{
					flag=0;
				}
				else{
					flag=1;
					printLine(lineNum*optionv, filename, line, pattern);
				}			
			}

			// " -H " option is used to print the file name for each match
			if (optionH)
			{
				if(checkStringMatch(line, pattern))
				{
					printLine(lineNum*optionH, filename, line, pattern);
				}			
			}

			// " -h " option is used to suppress the file name prefix on output
			if (optionh)
			{
				if(checkStringMatch(line, pattern))
				{
					printLine(lineNum*optionh, filename, line, pattern);
				}			
			}

			// " -r " option is used  Read all files  under  each  directory,  recursively
			if (optionr)
			{
				if(checkStringMatch(line, pattern))
				{
					printLine(lineNum*optionn, filename, line, pattern);

				}			
			}
			
			// " -f " option is used  to Obtain  patterns  from  FILE,  one  per  line. 
			if (optionf)
			{
				if(checkStringMatch(line, line1))
				{
					printLine(lineNum*optionf, filename, line, pattern);

				}			
			}

			// " -y " option is  Obsolete synonym for -i.
			if(optiony)
			{
				char* lowerLine = switchToLower(line);
				if(checkStringMatch(lowerLine, pattern))
				{
					printLine(lineNum*optiony, filename, line, pattern);
				}
				free(lowerLine);
			}

			// " -w " option is used Select  only  those  lines  containing  matches  that form whole words.
			if (optionw)
			{
				if(checkStringMatch(line, pattern))
				{
					printLine(lineNum*optionw, filename, line, pattern);
				}
			 }
			
						
			lineNum++;
		}
			
	
	}
			if(optionc){
				printf(MAG "%s :" RESET  , filename);
				printf("%d\n", count);	
			}
	// Close file and free line
	fclose(f);
	free(line);
}

char* getLine(char* loc, FILE* fileStream){
	return fgets(loc, MAX, fileStream);
}

int checkStringMatch(char* toSearch, char* pattern){
	char* exists = strstr(toSearch, pattern);
	if(exists)
		return 1;
	return 0;
}

char* switchToLower(char* str){ 
	char* newString = (char*)malloc(sizeof(char)*strlen(str));

	//Iterate through charaters in str, switch each letter to lowercase
	int i;
	for(i = 0; str[i]; i++)
	{
		newString[i]=tolower(str[i]);
	}

	return newString;
}
void setClr(char* arr, char* a){	
	int j;
	char temp[100];
	for(j=0;arr[j]!='\0';j++)
	{
		char * p=&arr[j];
		int lenOfA=strlen(a);
		strncpy(temp,p,lenOfA);
		if(!strcmp(temp,a))
		{
			while(lenOfA>0)
			{
				printf(RED "%c" RESET, arr[j]);
				lenOfA--;	
				j++;
			}
			j--;
		}
		else
			printf("%c", arr[j]); 
	}
}

void printLine(int lineNum, char* fileName, char* text, char* pattern){
	if(lineNum)
		if(optionn){
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			printf( GRN "%d" RESET  , lineNum);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		if(optioni){
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		if(optionv){
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			printf("%s", text);
			}
		if(optionH){
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		if(optionh){
			setClr(text,pattern);
			}
		if(optionr)
			{
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		if(optiony)
			{
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		if(optionf){
			setClr(text,pattern);
			}
		if(optionw){
			printf(MAG "%s" RESET  , fileName);
			printf(BLU ":" RESET);
			setClr(text,pattern);
			}
		return 0;
}

